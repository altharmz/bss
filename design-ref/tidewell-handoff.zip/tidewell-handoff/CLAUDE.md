# Design system

This project uses the Tidewell design system, located at `design-system/tidewell/`.

- Global styles: import `design-system/tidewell/styles.css` once at the app root.
- Tokens: `design-system/tidewell/tokens/*.css`. Always style with `var(--*)` tokens; do not hard-code colors, fonts, radii, spacing or shadows.
- Components: `design-system/tidewell/components/<group>/<Name>.jsx`. Each has a `.d.ts` (props) and `.prompt.md` (usage rules). Read them before use.
- Rules and voice: `design-system/tidewell/README.md`.
- Reference screens: `design-system/tidewell/ui_kits/app/`.
- For any UI work, use the `tidewell-design` skill.
