# Moving Tidewell into Claude Code

## What's in this folder
- `tidewell/`: the design system (tokens, `styles.css`, 16 React components, guideline cards, UI kit, README).
- `CLAUDE.md`: project memory that tells Claude Code where the system lives.
- `skill/SKILL.md`: a Claude Code skill that loads the rules before any UI work.

## Step 1. Unzip into your repo
Copy the folders into your project root so you end up with:
```
your-repo/
  CLAUDE.md                       <- from this folder (merge if you already have one)
  design-system/tidewell/         <- the tidewell/ folder
  .claude/skills/tidewell-design/SKILL.md   <- from skill/
```
Commands from the unzipped folder:
```
mkdir -p ../your-repo/design-system ../your-repo/.claude/skills/tidewell-design
cp -R tidewell ../your-repo/design-system/
cp skill/SKILL.md ../your-repo/.claude/skills/tidewell-design/
cat CLAUDE.md >> ../your-repo/CLAUDE.md
```

## Step 2. Make sure the app can run the components
The components are plain React (`.jsx`, ES modules, `import React from "react"`). You need React 18+ and a bundler that handles JSX (Vite, Next.js, etc.). No other dependencies.

No app yet? In Claude Code run:
> Create a Vite + React app in this folder and wire up the design system in design-system/tidewell.

## Step 3. Load the global styles
Import once at your app entry (e.g. `src/main.jsx` or `app/layout.tsx`):
```js
import "../design-system/tidewell/styles.css";
```
This pulls in fonts (Google Fonts: Newsreader, Schibsted Grotesk, Geist Mono), colors, type, spacing, effects and base resets.

## Step 4. Open Claude Code and check it picked everything up
```
cd your-repo
claude
```
Then ask:
> Summarize the design system you have access to.

It should mention the CLAUDE.md entry and list the `tidewell-design` skill. Type `/tidewell-design` to invoke it directly.

## Step 5. (Recommended) Have Claude Code adapt it to your stack
One prompt, adjusted to your setup:
> Convert design-system/tidewell/components to TypeScript (.tsx) using the existing .d.ts files, add an index file that exports every component, and set a path alias `@tidewell` for it. Don't change any visual values.

If you use Tailwind, add:
> Map the CSS variables in design-system/tidewell/tokens into tailwind.config theme (colors, radius, spacing, fontFamily, boxShadow) so utilities resolve to the tokens.

## Step 6. Build something
Example prompts:
> Using the tidewell-design skill, build the weekly board screen from ui_kits/app as real routes with our components.

> Add a settings page. Follow Tidewell rules: serif page title, underline tabs, one primary button.

Open `design-system/tidewell/ui_kits/app/index.html` in a browser any time to see the reference screens.

## Notes
- Icons load from the Lucide CDN (`lucide-static@0.460.0`). To work offline, ask Claude Code to install `lucide-react` and swap the `Icon` implementation, keeping the same `name` prop.
- Fonts load from Google Fonts. To self-host, replace the `@import` in `tokens/fonts.css` with `@font-face` rules.
- `guidelines/*.card.html` and `components/*/*.card.html` are visual specimens for reference only; they don't need to ship.
