---
name: tidewell-design
description: Use when building or changing any UI in this repo. Applies the Tidewell design system (tokens, React components, voice and visual rules).
user-invocable: true
---

Before writing UI code:
1. Read `design-system/tidewell/README.md` (foundations, voice, iconography).
2. Read the `.prompt.md` and `.d.ts` for every component you plan to use in `design-system/tidewell/components/`.
3. Use the CSS variables from `design-system/tidewell/tokens/` (`var(--accent)`, `var(--radius-md)`, etc.). Never hard-code hex values, font names, radii or shadows that a token already covers.

Rules:
- Compose from existing components (Button, IconButton, Input, Select, Checkbox, Radio, Switch, Card, Badge, Tag, Avatar, Icon, Tabs, Dialog, Toast, Tooltip). Do not restyle raw HTML to imitate them.
- Icons only through `<Icon name="…" />` (Lucide names).
- One primary button per view. Sentence case. No emoji, no exclamation marks.
- Warm neutrals only (sand scale). Shadows only on floating layers.
- For full-screen reference layouts, see `design-system/tidewell/ui_kits/app/`.

If asked to build something with no other guidance, ask what they want to build, then design it with these rules.
